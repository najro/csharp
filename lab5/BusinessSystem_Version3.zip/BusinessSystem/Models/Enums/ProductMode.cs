﻿namespace BusinessSystem.Models.Enums
{
    public enum ProductMode
    {
        New = 0,
        Edit = 1
    }
}
